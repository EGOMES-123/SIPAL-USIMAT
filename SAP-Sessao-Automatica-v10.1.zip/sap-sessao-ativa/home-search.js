(()=>{
 if(window.top!==window)return;
 const start=Date.now();let busy=false,clicks=0,lastClick=0,first=null,reported=false;
 const visible=e=>!!e&&e.isConnected&&e.getBoundingClientRect().width>0&&e.getBoundingClientRect().height>0&&!e.disabled&&e.getAttribute('aria-disabled')!=='true';
 function findSearch(){
 // Restrict to the Fiori shell header to avoid unrelated application buttons.
 const direct=['shell-header-search','searchFieldInShell-search','shellSearchButton'];
 for(const id of direct){const e=document.getElementById(id);if(visible(e))return e.closest('button,[role=button]')||e;}
 const root=document.getElementById('shell-header')||document.querySelector('header,[role=banner],.sapUshellShellHead');
 if(!root)return null;
 const candidates=[...root.querySelectorAll('button,[role=button]')].filter(visible).filter(e=>{
 const label=[e.getAttribute('aria-label'),e.getAttribute('title'),e.getAttribute('data-sap-ui-icon-content'),e.textContent].filter(Boolean).join(' ').trim();
 return /(?:^|\b)(?:procurar|pesquisar|pesquisa|buscar|busca|search)(?:\b|$)/i.test(label)&&!/avançad|advanced/i.test(label);
 });
 return candidates.length===1?candidates[0]:null;
 }
 const timer=setInterval(async()=>{
 if(busy)return;busy=true;
 try{
 if(Date.now()-start>180000){clearInterval(timer);return;}
 const c=await chrome.runtime.sendMessage({type:'robot-config'});if(!c?.active)return;
 if(!location.hash.startsWith('#Shell-home'))return;
 if(Date.now()-lastClick<1800)return;
 const button=clicks===1&&visible(first)?first:findSearch();
 if(!button){if(!reported&&Date.now()-start>20000){reported=true;await chrome.runtime.sendMessage({type:'search-progress',message:'Página aberta, mas lupa do cabeçalho ainda não identificada de forma única.'});}return;}
 if(clicks===0)first=button;
 button.click();clicks++;lastClick=Date.now();
 await chrome.runtime.sendMessage({type:'search-progress',message:'Clique '+clicks+'/2 acionado na lupa do cabeçalho.'});
 if(clicks===2){await chrome.runtime.sendMessage({type:'search-done',clicks:2});clearInterval(timer);}
 }catch{clearInterval(timer);}finally{busy=false;}
 },1000);
})();