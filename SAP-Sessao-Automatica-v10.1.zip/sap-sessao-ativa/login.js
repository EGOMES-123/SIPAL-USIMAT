// Acts only in the dedicated robot tab and on the requested Microsoft account.
// Checks only whether the password field is nonempty, locally; never stores or sends its contents or cookies.
(()=>{
 if(location.hostname!=='login.microsoftonline.com')return;
 let account='';const acted=new Set();const start=Date.now();
 let lastPassword=null,passwordFirstSeen=null,autofillSince=null;
 const visible=e=>!!e&&e.getBoundingClientRect().width>0&&e.getBoundingClientRect().height>0;
 const timer=setInterval(async()=>{
  try{
   const run=await chrome.runtime.sendMessage({type:'robot-config'});if(Date.now()-start>180000){clearInterval(timer);return;}if(!run?.active)return;account=String(run.account||'').toLowerCase();if(!account)return;
   const text=document.body.innerText||'';const button=document.getElementById('idSIButton9');
   if(/Continuar conectado\?/i.test(text)&&text.toLowerCase().includes(account)&&visible(button)&&/^Sim$/i.test(button.value||button.textContent.trim())&&!acted.has('stay')){acted.add('stay');button.click();return;}
   if(/Escolha uma conta/i.test(text)&&!acted.has('account')){
    // Some Microsoft account tiles have no role=button. Match only the exact account label,
    // then use its nearest tile/container so Microsoft's delegated click handler receives it.
    const labels=[...document.querySelectorAll('span,div,p,a,button')].filter(e=>visible(e)&&e.textContent.trim().toLowerCase()===account);
    const leaves=labels.filter(e=>!labels.some(child=>child!==e&&e.contains(child)));
    const targets=[...new Set(leaves.map(e=>e.closest('[data-test-id="userTile"],.tile,.table,[role="button"],button,a,[tabindex]')||e))].filter(visible);
    if(targets.length===1){acted.add('account');targets[0].click();await chrome.runtime.sendMessage({type:'robot-progress',phase:'login',message:'Conta Microsoft selecionada. Aguardando a próxima etapa do login.'});return;}
   }
   const password=document.querySelector('input[type="password"]');
   if(visible(password)&&text.toLowerCase().includes(account)&&visible(button)&&/^Entrar$/i.test(button.value||button.textContent.trim())&&!acted.has('signin')){
    // Check only whether the local field is filled. Never store or transmit its contents.
    const now=Date.now();
    if(lastPassword!==password){lastPassword=password;passwordFirstSeen=now;autofillSince=null;}
    const ready=password.value.length>0&&!button.disabled&&button.getAttribute('aria-disabled')!=='true';
    if(!ready)autofillSince=null;else if(autofillSince===null)autofillSince=now;
    if(ready&&now-passwordFirstSeen>=3000&&now-autofillSince>=3000){acted.add('signin');button.click();await chrome.runtime.sendMessage({type:'robot-progress',phase:'login',message:'Campo preenchido por pelo menos 3 segundos. Entrar acionado.'});return;}
    if(Date.now()-start>30000&&!acted.has('notice')){acted.add('notice');await chrome.runtime.sendMessage({type:'robot-progress',phase:'login',message:'O campo ainda está vazio ou o botão Entrar está indisponível. Confira a aba do robô; não envie sua senha.'});}
   }
  if(Date.now()-start>45000&&!acted.has('account-help')&&!visible(password)&&!/Continuar conectado\?/i.test(text)){acted.add('account-help');await chrome.runtime.sendMessage({type:'robot-progress',phase:'login',message:'Não identifiquei uma etapa de login com segurança. Confira a aba Microsoft do robô.'});}
  }catch{clearInterval(timer);}
 },1500);
})();
