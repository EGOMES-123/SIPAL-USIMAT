function sapExecuteButton(click=false){
 if(location.hostname!=='s4.sipal.com.br')return {count:0};
 const visible=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(e).visibility!=='hidden'};
 const blocked=[...document.querySelectorAll('[aria-busy="true"],.sapUiLocalBusyIndicator,.sapUiBusy,.sapUiBlockLayer,[role="progressbar"]')].some(visible);
 if(blocked)return {count:0,busy:true,clicked:false};
 const norm=v=>String(v||'').replace(/\s+/g,' ').trim();
 const found=[...document.querySelectorAll('button,[role="button"],a[title],a[aria-label],[ct="B"],input[type="submit"],input[type="button"]')].filter(e=>{
  const r=e.getBoundingClientRect();if(!r.width||!r.height||e.disabled||e.getAttribute('aria-disabled')==='true'||getComputedStyle(e).visibility==='hidden')return false;
  return [e.getAttribute('title'),e.getAttribute('aria-label'),e.querySelector('[id$="-caption"]')?.textContent,e.textContent,e.value].some(v=>/^Executar(?:\s*\(\s*F8\s*\))?$/i.test(norm(v)));
 });
 const buttons=found.filter(parent=>!found.some(child=>child!==parent&&parent.contains(child)));
 if(click&&buttons.length===1){buttons[0].focus?.({preventScroll:true});buttons[0].click();}
 return {count:buttons.length,clicked:click&&buttons.length===1};
}

if(typeof module!=='undefined')module.exports={sapExecuteButton};

// Read progress evidence, never infer a successful SAP request from .click().
function sapQueryEvidence(arm=false){
 if(location.hostname!=='s4.sipal.com.br')return {};
 const visible=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(e).visibility!=='hidden'};
 const searching=()=>/buscando\s+contratos?/i.test(document.body?.innerText||'');
 if(arm){
  globalThis.sapQueryEvidenceObserver?.disconnect();
  globalThis.sapQuerySearchSeen=false;
  const observer=new MutationObserver(()=>{if(searching()){globalThis.sapQuerySearchSeen=true;observer.disconnect();}});
  observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true});
  globalThis.sapQueryEvidenceObserver=observer;
 }
 const progress=searching()||globalThis.sapQuerySearchSeen===true;
 const rows=globalThis.sapReceiptCollect?.()?.rows?.length||0;
 if(rows>0)globalThis.sapQueryEvidenceObserver?.disconnect();
 const busy=[...document.querySelectorAll('[aria-busy="true"],.sapUiLocalBusyIndicator,.sapUiBusy,.sapUiBlockLayer,[role="progressbar"]')].some(visible);
 return {searching:searching(),searchSeen:progress,rows,busy,collectorAvailable:typeof globalThis.sapReceiptCollect==='function',gridHeaders:document.querySelectorAll('[role="columnheader"]').length,gridCells:document.querySelectorAll('[role="gridcell"]').length};
}
if(typeof module!=='undefined')module.exports.sapQueryEvidence=sapQueryEvidence;
