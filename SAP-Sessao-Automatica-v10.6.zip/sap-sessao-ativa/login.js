// Only acts in the extension-owned tab for the configured Microsoft account.
// Requires a nonempty password value for at least two seconds. Never logs or stores it.
(()=>{
 if(location.hostname!=='login.microsoftonline.com')return;
 const acted=new Set(),start=Date.now();let busy=false,lastPassword=null,readySince=null,preparedPassword=null;
 const visible=e=>!!e&&e.isConnected&&e.getBoundingClientRect().width>0&&e.getBoundingClientRect().height>0;
 const enabled=e=>visible(e)&&!e.disabled&&!e.matches(':disabled')&&e.getAttribute('aria-disabled')!=='true';
 const label=e=>String(e?.value||e?.textContent||'').trim();
 function autofilled(input){
  // Autofill styling is diagnostic only; never sufficient permission to submit.
  for(const selector of [':autofill',':-webkit-autofill']){try{if(input.matches(selector))return true;}catch{}}
  return false;
 }
 async function note(key,message){if(acted.has(key))return;acted.add(key);await chrome.runtime.sendMessage({type:'robot-progress',phase:'login',message});}
 const timer=setInterval(async()=>{
  if(busy)return;busy=true;
  try{
   if(Date.now()-start>180000){clearInterval(timer);return;}
   const run=await chrome.runtime.sendMessage({type:'robot-config'});if(!run?.active)return;
   const account=String(run.account||'').trim().toLowerCase();if(!account)return;
   const text=document.body.innerText||'',sameAccount=text.toLowerCase().includes(account);
   const button=document.getElementById('idSIButton9');
   if(/(?:Continuar conectado\?|Stay signed in\?)/i.test(text)&&sameAccount&&enabled(button)&&/^(?:Sim|Yes)$/i.test(label(button))&&!acted.has('stay')){acted.add('stay');button.click();return;}
   if(/(?:Escolha uma conta|Pick an account)/i.test(text)&&!acted.has('account')){
    const labels=[...document.querySelectorAll('span,div,p,a,button')].filter(e=>visible(e)&&e.textContent.trim().toLowerCase()===account);
    const leaves=labels.filter(e=>!labels.some(child=>child!==e&&e.contains(child)));
    const targets=[...new Set(leaves.map(e=>e.closest('[data-test-id="userTile"],.tile,.table,[role="button"],button,a,[tabindex]')||e))].filter(visible);
    if(targets.length===1){acted.add('account');targets[0].click();await note('account-log','Conta Microsoft selecionada. Aguardando a etapa de senha.');return;}
   }
   const password=document.querySelector('input[type="password"]');
   const error=document.getElementById('passwordError');
   if(visible(error)&&String(error.textContent||'').trim()){
    acted.add('signin');readySince=null;
    await note('microsoft-error','A Microsoft informou um erro de senha/login. Nenhuma nova tentativa será enviada nesta página; confira a credencial salva no Chrome.');return;
   }
   if(visible(password)&&!acted.has('signin')){
    if(lastPassword!==password){lastPassword=password;readySince=null;}
    if(!sameAccount){readySince=null;await note('account-mismatch','A conta exibida não corresponde ao e-mail configurado. Login preservado para conferência.');return;}
    if(preparedPassword!==password){
     // Request one click on noninteractive whitespace of the login card.
     // DOM clicks are untrusted: Chrome may still require a physical gesture.
     const card=document.getElementById('lightbox');
     const heading=document.getElementById('loginHeader')||document.querySelector('h1,[role="heading"]');
     const target=visible(card)?card:visible(heading)?heading:null;
     if(target&&!target.closest('a,button,input,select,textarea,[role="button"]')){
      preparedPassword=password;readySince=null;
      password.blur();
      target.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));
      readySince=password.value&&enabled(button)?Date.now():null;
      await note('prepare-click','Clique solicitado na área branca do cartão de login. Aguardando a senha ficar disponível; o Chrome ainda pode exigir um clique real.');
      return;
     }
    }
    const filled=Boolean(password.value);
    if(!filled){
     readySince=null;
     if(autofilled(password))await note('autofill-pending','O Chrome mostra autopreenchimento, mas o campo ainda está vazio para envio. Entrar não será acionado até o valor estar disponível.');
     else if(Date.now()-start>30000)await note('password-empty','O campo de senha ainda está vazio para envio. Aguardando o preenchimento do Chrome.');
     return;
    }
    if(!visible(button)||!/^(?:Entrar|Sign in)$/i.test(label(button))){readySince=null;await note('signin-missing','Valor de senha disponível no campo, mas o botão Entrar não foi identificado.');return;}
    if(!enabled(button)){readySince=null;await note('signin-disabled','Valor de senha disponível no campo; o botão Entrar está desabilitado pela página.');return;}
    if(readySince===null){readySince=Date.now();await note('password-ready','Valor de senha disponível no campo. Aguardando pelo menos 2 segundos antes de Entrar.');}
    if(Date.now()-readySince>=2000){
     // Notify the page about the already-filled field without changing its value.
     password.dispatchEvent(new Event('input',{bubbles:true,composed:true}));
     password.dispatchEvent(new Event('change',{bubbles:true}));
     // A page handler may clear or replace the field. Never submit after that.
     if(!password.isConnected||document.querySelector('input[type="password"]')!==password||!password.value||!enabled(button)){readySince=null;return;}
     acted.add('signin');button.click();
     await note('signin-log','Entrar acionado uma vez. Aguardando resposta da Microsoft; isso ainda não confirma o login.');
    }
    return;
   }
   if(Date.now()-start>45000&&!visible(password)&&!/(?:Continuar conectado\?|Stay signed in\?)/i.test(text))await note('step-help','Etapa não reconhecida ou autenticação adicional. Confira a janela auxiliar; MFA exige sua ação.');
  }catch{clearInterval(timer);}finally{busy=false;}
 },1000);
})();
