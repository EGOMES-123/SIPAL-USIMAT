const $=s=>document.querySelector(s);let loaded=false,snapshot;
async function send(data){const result=await chrome.runtime.sendMessage(data);if(result?.error)throw Error(result.error);return result;}
async function render(){
 try{
 const s=await send({type:'status'});snapshot=s;
 if(!loaded){$('#account').value=s.account;$('#interval').value=s.interval;$('#autoLogin').checked=s.autoLogin;loaded=true;}
 $('#status').textContent=s.paused?'Automática · nova tentativa agendada':s.pending?.ready?'Automática · aguardando janela auxiliar ficar sem foco':s.pending?'Automática · aguardando SAP e um clique na lupa':'Automática · aguardando próximo ciclo';
 updateClock();
 $('#logs').replaceChildren();
 for(const row of s.logs){const div=document.createElement('div');div.className='entry';div.textContent=new Date(row.time).toLocaleString('pt-BR')+' — '+row.message;$('#logs').append(div);}
 if(!s.logs.length)$('#logs').textContent='Nenhum evento registrado.';
 }catch(e){$('#feedback').textContent='Não foi possível ler o estado: '+e.message;}
}
async function action(data){const buttons=[...document.querySelectorAll('button')];buttons.forEach(b=>b.disabled=true);try{await send(data);$('#feedback').textContent='Comando concluído.';await render();}catch(e){$('#feedback').textContent=e.message;}finally{buttons.forEach(b=>b.disabled=false);}}

$('#clear').onclick=()=>action({type:'clear-logs'});
$('#settings').onsubmit=e=>{e.preventDefault();action({type:'save',account:$('#account').value,interval:Number($('#interval').value),autoLogin:$('#autoLogin').checked});};
$('#export').onclick=async()=>{
 await render();if(!snapshot)return;
 const {account,logs,...s}=snapshot;
 // Redact the configured account should a future event include it.
 const clean=logs.map(row=>({...row,message:account?row.message.split(account).join('[e-mail omitido]'):row.message}));
 const data={version:chrome.runtime.getManifest().version,exportedAt:new Date().toISOString(),state:s,logs:clean};
 const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));
 const a=document.createElement('a');a.href=url;a.download='SAP-diagnostico.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);
};
function updateClock(){
 const s=snapshot;if(!s)return;
 if(!s.next){$('#next').textContent='Próxima abertura: iniciando agora…';$('#countdown').textContent='';return;}
 $('#next').textContent=(s.paused?'Nova tentativa automática às ':'Próxima abertura às ')+new Date(s.next).toLocaleTimeString('pt-BR');
 const seconds=Math.ceil((s.next-Date.now())/1000);
 $('#countdown').textContent=seconds>0?'Faltam '+String(Math.floor(seconds/60)).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0'):s.pending?'Horário previsto atingido. Aguardando o ciclo atual ou a janela ficar sem foco.':'Horário previsto atingido. Aguardando o alarme do Chrome.';
}
chrome.storage.onChanged.addListener(()=>render());render();setInterval(updateClock,1000);

