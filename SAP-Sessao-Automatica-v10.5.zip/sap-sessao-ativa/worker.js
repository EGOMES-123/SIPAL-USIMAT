const SAP='https://s4.sipal.com.br/', HOME=SAP+'sap/bc/ui2/flp#Shell-home', CLOCK='sap-home-v10';
const DEFAULTS={enabled:true,interval:4,autoLogin:false,account:''};
let queue=Promise.resolve();
function serial(fn){const next=queue.then(fn);queue=next.catch(()=>{});return next;}
async function settings(){return {...DEFAULTS,...await chrome.storage.local.get(Object.keys(DEFAULTS))};}
async function state(){return chrome.storage.session.get(['pending','owned','paused','next']);}
async function log(message){const {logs=[]}=await chrome.storage.local.get('logs');await chrome.storage.local.set({logs:[{time:Date.now(),message},...logs].slice(0,100)});}
async function badge(text){await chrome.action.setBadgeText({text});}
async function pause(message){const cfg=await settings();await chrome.storage.session.set({paused:true,next:Date.now()+cfg.interval*60000});await badge('!');await log(message+' Nova tentativa automática agendada; janelas preservadas.');}
function safeTab(tab){return typeof tab?.url==='string'&&tab.url.startsWith(SAP)&&tab.url.includes('#Shell-home');}
async function finish(){
 const s=await state();if(!s.pending?.ready)return;
 // Never close a focused window, even the newly prepared window.
 let current;try{current=await chrome.windows.get(s.pending.windowId,{populate:true});}catch{await pause('A janela nova foi fechada antes da conclusão.');return;}
 if(!current.tabs||current.tabs.length!==1||current.tabs[0].id!==s.pending.tabId||!safeTab(current.tabs[0])){await pause('A janela auxiliar mudou de página ou recebeu outra aba; preservada.');return;}
 if(current.focused)return;
 if(s.owned){
  let previous;try{previous=await chrome.windows.get(s.owned.windowId,{populate:true});}catch{}
  if(previous){
   if(previous.focused)return;
   if(previous.tabs?.length===1&&previous.tabs[0].id===s.owned.tabId&&safeTab(previous.tabs[0])){
    try{await chrome.windows.remove(previous.id);}catch{await pause('Não foi possível substituir a janela anterior.');return;}
   }else await log('Janela anterior modificada: preservada e retirada do controle da extensão.');
  }
 }
 const cfg=await settings();
 await chrome.storage.session.set({owned:{windowId:s.pending.windowId,tabId:s.pending.tabId},pending:null,next:s.next||Date.now()+cfg.interval*60000});
 await badge(cfg.interval+'m');await log('Clique único solicitado na lupa Procurar. Próxima abertura programada às '+new Date(s.next||Date.now()+cfg.interval*60000).toLocaleTimeString('pt-BR')+'. Renovação no servidor ainda não comprovada.');
}
async function tick(){
 const cfg=await settings(),s=await state();
 if(s.paused){
  if(s.next&&Date.now()<s.next)return;
  if(s.pending){
   let win;try{win=await chrome.windows.get(s.pending.windowId,{populate:true});}catch{}
   if(win){
    if(win.focused){await chrome.storage.session.set({next:Date.now()+30000});return;}
    const tab=win.tabs?.find(t=>t.id===s.pending.tabId);
    // Retry only an untouched auxiliary home page. Preserve login/MFA pages.
    if(win.tabs?.length!==1||!safeTab(tab)){await pause('A janela auxiliar precisa de conferência (login, outra página ou outras abas).');return;}
    await chrome.storage.session.set({paused:false,pending:{...s.pending,started:Date.now(),ready:false},next:Date.now()+cfg.interval*60000});
    await chrome.tabs.reload(tab.id);await log('Nova tentativa automática na mesma janela auxiliar.');return;
   }
  }
  await chrome.storage.session.set({paused:false,pending:null,next:null});
  return tick();
 }
 if(s.pending){
  if(s.pending.ready)await finish();
  else if(Date.now()-s.pending.started>=180000)await pause('O ciclo excedeu 3 minutos sem confirmar os cliques.');
  return;
 }
 if(s.next&&Date.now()<s.next)return;
 // Check an existing auxiliary window before creating another one.
 if(s.owned){try{const old=await chrome.windows.get(s.owned.windowId);if(old.focused)return;}catch{}}
 const win=await chrome.windows.create({url:HOME,type:'normal',focused:false});
 const tab=win.tabs?.[0];
 if(!tab?.id){await pause('O Chrome não informou a aba criada.');return;}
 await chrome.storage.session.set({pending:{windowId:win.id,tabId:tab.id,started:Date.now(),ready:false},next:Date.now()+cfg.interval*60000});
 try{await chrome.tabs.update(tab.id,{autoDiscardable:false});}catch{}
 await badge('…');await log('Janela auxiliar aberta. Aguardando SAP e um clique na lupa.');
}
async function guardedTick(){try{await tick();}catch(e){await pause('Falha no ciclo: '+String(e.message||e).slice(0,200));}}
chrome.alarms.onAlarm.addListener(a=>{if(a.name===CLOCK)serial(guardedTick);});
chrome.windows.onFocusChanged.addListener(()=>serial(guardedTick));
chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
 serial(async()=>{
  const cfg=await settings(),s=await state();
  const own=!!s.pending&&sender.tab?.id===s.pending.tabId;
  const sap=sender.url?.startsWith(SAP),ms=sender.url?.startsWith('https://login.microsoftonline.com/');
  const popup=!sender.tab&&sender.url===chrome.runtime.getURL('popup.html');
  if(msg.type==='robot-config')return {active:own&&cfg.enabled&&!s.paused&&(sap||ms),account:cfg.autoLogin?cfg.account:'',home:true};
  if(own&&cfg.enabled&&!s.paused){
   if((msg.type==='robot-progress'&&ms)||(msg.type==='search-progress'&&sap)){await log(String(msg.message).slice(0,300));return {ok:true};}
   if(msg.type==='search-done'&&sap&&msg.clicks===1){await chrome.storage.session.set({pending:{...s.pending,ready:true}});await finish();return {ok:true};}
  }
  if(!popup)return {ok:false};
  if(msg.type==='status'){const {logs=[]}=await chrome.storage.local.get('logs');return {...cfg,...s,logs};}
  if(msg.type==='save'){
   const account=String(msg.account||'').trim().toLowerCase();
   if(account&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(account))return {error:'Informe um e-mail válido.'};
   const interval=Number(msg.interval);if(![2,3,4].includes(interval))return {error:'Escolha 2, 3 ou 4 minutos.'};
   await chrome.storage.local.set({account,interval,autoLogin:msg.autoLogin===true});
   if(s.next)await chrome.storage.session.set({next:Date.now()+interval*60000});
   await log('Preferências salvas neste navegador.');return {ok:true};
  }
  if(msg.type==='clear-logs'){await chrome.storage.local.set({logs:[]});return {ok:true};}
  return {ok:false};
 }).then(reply).catch(async e=>{reply({error:String(e.message||e)});});return true;
});
async function init(){
 const alarms=await chrome.alarms.getAll();
 for(const a of alarms)if(a.name!==CLOCK)await chrome.alarms.clear(a.name);
 await chrome.alarms.create(CLOCK,{periodInMinutes:0.5});
 await chrome.storage.local.set({enabled:true});
 await badge('AUTO');
 await guardedTick();
}
chrome.runtime.onInstalled.addListener(()=>serial(init));
chrome.runtime.onStartup.addListener(()=>serial(init));
// Run initialization on every worker load, including developer-mode reload.
serial(init).catch(e=>serial(()=>pause(String(e.message||e))));
